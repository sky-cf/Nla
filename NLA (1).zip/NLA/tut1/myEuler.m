function [val] = myEuler(f,x_0,x_last,y_0,h)
y(1) = y_0;
x = x_0:h:x_last;
N = length(x);
for i=1:N-1
    y(i+1) = y(i) + h*f(x(i),y(i));
end
val = y(i+1);
fprintf('itr taken = %d and y(%f) = %.8f\n',i , x(i+1),y(i+1));
end