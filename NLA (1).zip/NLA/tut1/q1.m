clc;
clear all
f = @(x,y) -2.*x.*y;
sol = @(x) exp(-x.^2);
a=0;
b=3;
y_0 = 1;
h = 0.03;
val1 = myEuler(f,a,b,y_0,h);
exact1 = sol(b);
fprintf('y(%d)= %.8f and abs err = %.2e',b,val1,abs(val1-exact1));

