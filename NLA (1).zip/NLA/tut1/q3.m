clc;
clear all
f = @(x,y) -2.*x.*y./(1+x.^2);
sol = @(x) 1./(1+x.^2);
a=0;
b=1;
y_0 = 1;
h = 0.1;
val1 = myEuler(f,a,b,y_0,h);
exact1 = sol(b);
fprintf('y(%f)= %.8f and abs err = %.2e',b,val1,abs(val1-exact1));