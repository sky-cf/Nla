clc;
clear all
f = @(x,y) 4.*y-1;
sol = @(x) (3.*exp(4.*x) +1)./4;
a=0;
b=0.5;
y_0 = 1;
h = 0.05;
val1 = myEuler(f,a,b,y_0,h);
exact1 = sol(b);
fprintf('y(%f)= %.8f and abs err = %.2e',b,val1,abs(val1-exact1));

