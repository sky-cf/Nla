clc;
clear all;

t = -5:0.5:6;

f = @(t) sin(pi.*t) + t./5;

b = f(t)';

n = 19 ;    % poly degree also A belongs to R(m,n)  

for i = 1:n
    A(:,i) = t.^(i-1);
end

 %A   % Vandermonde matrix


%...................cgs................

[Q R] = cgsqr([A b]);

x = R(1:n,1:n)\R(1:n,n+1);

[Qc Rc] = cgsqr(A);

xc = Rc\Qc'*b;
x
xc


plot(t,polyval(flip(x),t), 'k')
hold on
plot(t,polyval(flip(xc),t), 'r')
hold on
plot(t,f(t), 'g')

legend('cgs aug','cgs','exact')

res1 = norm(A*x - b)
res2 = norm(A*xc - b)





