clc;
clear all;

t = -5:0.5:6;

f = @(t) sin(2*pi.*t) + t./5;

b = f(t)';

n = 19 ;    % poly degree also A belongs to R(m,n)  

for i = 1:n
    A(:,i) = t.^(i-1);
end

 %A   % Vandermonde matrix


%...................cgs................

[Q R] = qr([A b]);

x = R(1:n,1:n)\R(1:n,n+1);

[Qc Rc] = qr(A);

xc = Rc\Qc'*b;
x
xc


plot(t,polyval(flipud(x),t), '')
hold on
plot(t,polyval(flipud(xc),t), 'r')
hold on
plot(t,f(t), 'g')

legend('qr aug','qr','exact')

res1 = norm(A*x - b)
res2 = norm(A*xc - b)





