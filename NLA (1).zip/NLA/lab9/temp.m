t = -5:0.5:6
f = @(t) sin(pi.*t) + t./5;

plot(t,f(t))