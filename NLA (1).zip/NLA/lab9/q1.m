clc;
clear all;

n = 7;

H = hilb(n);

[Q1 R1] = qr(H);  %simple

derivation = norm(Q1'*Q1 - eye(n))

E1 =  norm(Q1*R1 - H); % residual

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Q2 R2] = cgsqr(H);  %cgs

cgs_derivation = norm(Q2'*Q2 - eye(n))

E2 =  norm(Q2*R2 - H); % residual

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Q3 R3] = mgsqr(H);  %mgs

Mgs_derivation = norm(Q3'*Q3 - eye(n))

E3 =  norm(Q3*R3 - H); % residual

u = Mgs_derivation/cond(H)
