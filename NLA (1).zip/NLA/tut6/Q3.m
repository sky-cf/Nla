clc;
clear all;

h = linspace(-1,1,50);
d = 1./(1+25.*(h.^2));
    

%%% Form the 4x2 matrix A and solve for the coefficient vector c.
A = [ones(size(h')), h', h.^2', h.^3',h.^4',h.^5', h.^6',h.^7', h.^8', h.^9', h.^10'];
c = A\d';
% solution of the LSP Ac =d
cc = flipud(c);
% order the coefficients in descending
% order for polyval
%%% Plot the data points
plot(h,d,'b'), title('Least Squares Linear Fit'), 
hold
xlabel('release height'); 
ylabel('horizontal distance');

%%% Plot the line of best fit
hmin = min(h); 
hmax = max(h);
h1 = [hmin:(hmax-hmin)/30:hmax];

plot(h1, polyval(cc, h1'), 'r'), axis tight;

r = norm(A*c-d)