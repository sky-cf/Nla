clc;
clear all;

n = 100; 

format long e

A = diag((-2)*ones(1,n),0) + diag((1)*ones(1,n-1),-1) + diag((1)*ones(1,n-1),1);

m = 1:8;

for i = 1:length(m)-1

D1 = myqr(A,m(i));

D2 = myqr(A,m(i+1));

err(i) = abs(log(D1(n,n-1)./D2(n,n-1)));

end

err
