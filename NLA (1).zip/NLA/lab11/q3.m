clc;
clear all;
tol = 1e-6;

A = randn(8); 
eig(A)

sum( abs( imag ( eig(A) ) ) < tol) % how many real eigen values

for i=1:1000
    A = randn(10);
    sumit(i) = sum( abs( imag ( eig(A) ) ) < tol);
end

histogram(sumit);