clc;
clear all;
n = 5; 

% Mdiag = repmat(-2,n,1); Ldiag = repmat(1,n-1,1); Udiag = repmat(1,n-1,1);

% or A = diag(Mdiag) + diag(Udiag,1) + diag(Ldiag,-1);



A = diag((-2)*ones(1,n),0) + diag((1)*ones(1,n-1),-1) + diag((1)*ones(1,n-1),1);


u =eps/2;
for  k=n:-1:1
    while abs(A(k,k-1))  > u*(abs(A(k-1,k-1)) +abs(A(k,k)) )
        del = (A(k- 1,k-1)-A(k,k))./2;
        mu =A(k,k) +del-sign(del)*sqrt(del.^2 +abs(A(k,k-1)).^2);
        [Q,R] = qr(A(1:k,1:k) - mu*ones(k));
        A(1:k,1:k) = R*Q+ mu*ones(k);
    end
        A(k,k-1) =0;   %  acceptA(k,k)as eigenvalue
        A(k-1,k) =0;   % acceptA(k,k)as eigenvalueend
end

A