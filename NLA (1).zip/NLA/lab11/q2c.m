clc;
clear all;

n = 100; 


A = diag((-2)*ones(1,n),0) + diag((1)*ones(1,n-1),-1) + diag((1)*ones(1,n-1),1);

m = 50;

D = myqr(A,50);

diag(D,-1)

T = eig(A);

sort(diag(D)') - sort(T')

norm(sort(T') - sort(diag(D)'))

