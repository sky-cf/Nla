function [Ans] = myqrWilkShift(A,m)

t = A;

n=min(size(t));

NN = [ t(n,n-1), t(n,n) ];

for i=1:m

  lc=t(n-1:n,n-1:n);
  elc=eig(lc);
  if ( abs(t(n,n)-elc(1)) < abs(t(n,n)-elc(2)) )
      shift = elc(1);
  else
      shift = elc(2);
  end

  [q,r]=qr(t-shift*eye(n));
  t=r*q+shift*eye(n);
  t = tril(triu(t,-1),1); 
  t = (t+t')/2;

  NN = [NN;[t(n,n-1),t(n,n)]];
end
NN = [NN,NN(:,2)-NN(m+1,2)];


Ans = t;

end