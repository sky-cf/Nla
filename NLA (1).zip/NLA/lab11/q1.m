clc;
clear all;

format long e
f = sqrt(eps);
A = [ 1 f; f 1];
A1 = A;
T1 = eig(A);

fprintf("Eigen value by eig : \n");

 T1 = T1'

for i = 1:10
    [Q,R] = qr(A);
    T = R*Q;
    A = T;
end

fprintf("Eigen value by qr step : \n");

T2 = sort(diag(T)')

p = charpoly(A1);

fprintf("Eigen value by char poly step : \n");
rt = roots(p);
T3 = sort(rt')

fprintf('diff in eig & qr step %e\n',norm(T1 -T2));
fprintf('diff in eig & char poly step %e\n',norm(T1 -T3));
fprintf('diff in char poly & qr step step %e\n',norm(T3 -T2));
