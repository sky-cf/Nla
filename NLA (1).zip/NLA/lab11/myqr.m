function D = myqr(A,m)
n = size(A);
for j = 1:m
M = A(end-1:end,end-1:end);
e = eig(M);
ab = [abs(e(1)-A(end,end)), abs(e(2)-A(end,end))];
if ab(1)<ab(2)
mu = e(1);
else
mu = e(2);
end

[Q,R] = qr(A-mu.*eye(n(1)));
A = R*Q + mu.*eye(n(1));
end
D = A;
end