% array & matrices
clc;
clear all
A = [1 2 3 ; 4 5 6 ; 7,8, 9];
B = [1 ; 2 ; 3];
A
B
size = [size(A) size(B)] % 3*3 , 3*1
dim = [ndims(A) ndims(B)] % 2-D
len = length(B)

combined_mat = [A B]  % right coz A,B has same no of columns
new_mat = [[1 2 ; 3 4] [5 ; 6]]
empty_mat = []

eye_mat = eye(3)
Diag_mat = diag([1 2 3])

mat1 = [zeros(2,3) ones(2,4)]

% colon operator 
i1 = 1:8
i2 = 0:2:10
i3 = 1:-0.5:-1

A(1,3) % single ele
B([1 3]) % multielement

A

A(2:3,2:3)  % submatrix = 2 to 3 row and 2 to 3 row
A(2:end,2:3)
A(:,2) % all rows of column 2 or can say column2
B(:,[1 1 1 1]) % multiple copies of column 1
A(:,[1 2 1 1])

B = floor(5*rand(2,4))  %imp
B>2      % 1,0 element
B(B==0) = NaN  %when B==0 show NaN
