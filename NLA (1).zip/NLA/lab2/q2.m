clc;
clear all;
% x'^2 -(10^7 + 10^-7) -1
a = 1;
b = 1e+7 + 1e-7;
c = -1;
[x1, x2] = quadroot1(a,b,c);
x1
x2

[y1, y2] = quadroot2(a,b,c);
y1
y2
