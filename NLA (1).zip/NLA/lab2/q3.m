clc;
clear all
x = 2;
while x > 1
x = x/2;
end
x
y = 2;
while 1+y > 1
y = y/2;
end
y

