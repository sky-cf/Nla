clc;
clear all;
A = [1e-20 1 ; 1 1];
%A = [1 2 3; 3 4 5; 6 7 8];
[L1, U1] = GENP(A);
E1 = L1*U1 - A;
GENPerr = norm(E1)

[L2, U2, p2] = GEPP(A);
E2 = L2*U2 - A(p2,:);
GEPPerr = norm(E2)

[L3,U3, p3, q3] = GECP(A);
E3 = L3*U3 - A(p3,q3);
GECPerr = norm(E3)


