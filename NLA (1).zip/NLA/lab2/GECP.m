function [L,U,p,q] = GECP(A)
[n, n] = size(A);
p = (1:n);

q = (1:n);

for k = 1:n-1
% find largest element in A(k:n,k)
[r, m] = max( abs( A(k:n,k:n) ) );
m = m+k-1;
if (m ~=k) % swap row & column
A([k m],:) = A([m k],:);
A(:,[k m]) = A(:,[m k]);
p([k m]) = p([m k]);
q([k m]) = q([m k]);
end
if (A(k,k) ~= 0)
% compute multipliers for k-th step
A(k+1:n,k) = A(k+1:n,k)/A(k,k);
% update A(k+1:n,k+1:n)
j = k+1:n;
A(j,j) = A(j,j)-A(j,k)*A(k,j);
end
end
% strict lower triangle of A, plus I
L = eye(n,n)+ tril(A,-1);
U = triu(A); % upper triangle of A
end