function[W] = wilk(n)
   
A = -1*ones(n);
W1= eye(n);
W2 = tril(A,-1);
W2(1:n-1,n) = 1;
W = W1 + W2;


end