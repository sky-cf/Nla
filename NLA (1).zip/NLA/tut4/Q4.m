clc;
clear all;
n=64;
W = wilk(n);

x = rand(n,1);

b=W*x;

x1 = W\b;

err1 = norm(x-x1,Inf)./norm(x,Inf);
err1

[Q R] = qr(W);
y = Q'*b;

x2 = R\y;

err2 = norm(x-x2,Inf)./norm(x,Inf);
err2
