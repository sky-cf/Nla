clc;
clear all;
close all;
n=2:10

for i=1:length(n)
A = golub(n(i));

[L U] = GENP(A);

growth(i) = max(max(abs(U)))/max(max(abs(A)));

condi(i) = cond(A);

end

plot(log(condi),growth);