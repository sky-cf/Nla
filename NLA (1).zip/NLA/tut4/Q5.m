clc;
clear all
close all
N = 10:0.5:505;
X = 2.^(N-1);

semilogy(N,X,'-')
hold on

n = 10:20:500;
m = length(n);
G = zeros(m,1);

for i = 1:m
W = wilk(n(i));
[L,U,p] = lu(W);
G(i) = max(max(abs(U)))/(max(max(abs(W))));
end

semilogy(n,G,'b*')

legend('1st','2nd');
hold off