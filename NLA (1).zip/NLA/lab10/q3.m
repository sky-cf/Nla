clc;
clear all;

A = gallery(5)

A^5    % A^5 = 0 so lambda^5 = 0, so lambda = 0

e = eig(A)

plot(real(e),imag(e),'r*',0,0,'ko')

e1 = eig(A + eps*randn(5,5).*A)
hold on
plot(real(e1),imag(e1),'b*',0,0,'ko')

axis(.1*[-1 1 -1 1])
axis square

f = rand(5);

norm(A)