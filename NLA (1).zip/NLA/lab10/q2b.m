clc;
clear all;

format long e

n = [8 10 12];
for i=1:length(n)
F = gallery('frank',n(i)); %frank simple high sensitive matrix with l & 1/l eigen values
F1 = F;
F2 = F;

F1(n(i),1) = 1e-10;
F2(1,n(i)) = 1e-10;

[V ,D ,s] = condeig(F);

[V1 ,D1 ,s1] = condeig(F1);

[V2 ,D2 ,s2] = condeig(F2);


 
bound_F1(i) = (norm(sort(diag(D)) - sort(diag(D1))))/norm(s*eps - eps^2);

bound_F2(i) = (norm(sort(diag(D)) - sort(abs(diag(D2)))))/norm(s*eps - eps^2);

cond_F(i) = cond(V);
cond_F1(i) = cond(V1); % coz f1 eig vector cond are same as F(hissenberg), thats why f1 shows right bound
cond_F2(i) = cond(V2);


end

%bound_F1(i) = (norm(diag(D) - diag(D1)))/norm(s - eps^2);

bound_F1
bound_F2

cond_F
cond_F1
cond_F2


