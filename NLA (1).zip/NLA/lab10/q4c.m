clc;
clear all;

W = zeros(20);

W = diag([20:-1:1])+ diag( 20 * ones(1,19), 1);

[V ,D ,s] = condeig(W);

W1 = W;

W1(20,1) = 1e-15;


[V ,D ,s] = condeig(W);

[V1 ,D1 ,s1] = condeig(W1);


jordan(W)
jordan(W1)

bound_W1 = (norm(sort(diag(D)) - sort(diag(D1))))/norm(s*eps - eps^2)


