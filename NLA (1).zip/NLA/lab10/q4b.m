clc;
clear all;

W = zeros(20);

W = diag([20:-1:1])+ diag( 20 * ones(1,19), 1);


for i=1:500
    n = rand;
    pos1 = randi([1 20]);
    pos2 = randi([1 20]);
    W1 = W;
    W1(pos1,pos2) = n*1e-12;
    e = eig(W1);
    plot(real(e),imag(e),'r*',0,0,'ko')
    hold on
    axis(.1*[-1 1 -1 1])
    axis square
end
