clc;
clear all;

n = 8:2:16;
for i=1:length(n)
A = gallery('frank',n(i)); %frank simple high sensitive matrix with l & 1/l eigen values

[V ,D ,s] = condeig(A);
[diag(D),s]  % s = cond no of eigen values

cond_V(i) = cond(V);
cond_V(i)
end


