clc;
clear all;

n = [4 5 6];
for i=1:length(n)
A = magic(n(i));
A
[V, D] = eig(A);
fprintf('largest eigen value by eig = %f\n',max(diag(D)));

T = schur(A);
fprintf('largest eigen value by schur = %f\n',max(diag(T)));
end
