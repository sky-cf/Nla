clc;
clear all;

W = zeros(20);

W = diag([20:-1:1])+ diag( 20 * ones(1,19), 1);

[V ,D ,s] = condeig(W);

W1 = W;
W2 = W;
W3 = W;
W1(20,1) = 7.8*1e-10;
W2(20,1) = 7.5*1e-12;
W3(20,1) = 7.8*1e-14;

[V ,D ,s] = condeig(W);

[V1 ,D1 ,s1] = condeig(W1);
[V2 ,D2 ,s2] = condeig(W2);
[V3 ,D3 ,s3] = condeig(W3);

diag(D1)'
diag(D2)'
diag(D3)'
diag(D)'

bound_W1 = (norm(diag(D) - diag(D1)))/norm(s*eps - eps^2)

bound_W2 = (norm(diag(D) - diag(D2)))/norm(s*eps - eps^2)

bound_W3 = (norm(diag(D) - diag(D3)))/norm(s*eps - eps^2)
