clc;
clear all;

F = gallery('frank',12);
e = [1e-5 1e-7 1e-9];

for j =1:3 
for i=1:1000
    n = rand;
    pos1 = randi([1 12]);
    pos2 = randi([1 12]);
    F1 = F;
    F1(pos1,pos2) = n*e(j);
    e = eig(F1);
    plot(real(e),imag(e),'r*',0,0,'ko')
    hold on
    axis(.1*[-1 1 -1 1])
    axis square
end
end