clc;
clear all;

X = linspace(0,1,50)';
range = 7:16;

for r = 1:length(range)  % range 7:16
   
for i = 1:range(r)
    A(:,i) = X.^(i-1);
end


w = randn(range(r),1);

b = A*w;

xhat = (A'*A)\(A'*b); % normal eq to solve lsp

xtilde = A\b;

rel1(r) = norm(xhat-w)/norm(w);
rel2(r) = norm(xtilde-w)/norm(w); 

rhat = b - A*xhat;
rtilde = b - A*xtilde;


sol1(r) = norm(rhat)/norm(b);
sol2(r) = norm(rtilde)/norm(b);
 
conds(r) = cond(A);  

end

semilogy(range,rel1);
hold on
semilogy(range,rel2);
hold on
semilogy(range,sol1);
hold on
semilogy(range,sol2);
legend('rel1','rel2','sol1','sol2')
conds

