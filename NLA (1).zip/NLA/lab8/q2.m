clc;
clear all;
A = gallery('kahan', 90, 1.2, 0); % generates Kahan matrix
sig = svd(A); % computes singular values.

format short e
sig(1)
sig(89)
sig(90)

fprintf('svd rank A = %d\n',rank(A));

[Q,R,E] = qr(A);

%[Q,R,P] = qr(A) additionally returns a permutation matrix P such that A*P = Q*R.

dif = norm(eye(90)-E);
dif      %dif = 0 so no pivoiting

R(90,90)
min(diag(R))


