clc;
clear all;

R = triu(randn(50));

[Q,X] = qr(randn(50));

A = Q*R;  % A is a matrix with known QR factors.

[S,T] = qr(A); % Computes Householder QR factorization of A.

E = S*T - A;

norm(E)      % backward stable

[norm( Q-S ), norm( R-T )]  % diff btw exact and our qr so, not forward stable