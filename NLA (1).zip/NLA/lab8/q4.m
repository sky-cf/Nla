clc;
clear all;

X = linspace(0,1,50)';

for i = 1:7
    A(:,i) = X.^(i-1);
end

A   % Vandermonde matrix

w = randn(7,1);

b = A*w;

xhat = (A'*A)\(A'*b) % normal eq to solve lsp

xtilde = A\b

[norm(xhat-w)/norm(w) , norm(xtilde-w)/norm(w)]   % qr via reflector

rhat = b - A*xhat;
rtilde = b - A*xtilde;

[norm(rhat)/norm(b), norm(rtilde)/norm(b)]
 
cond(A)  


