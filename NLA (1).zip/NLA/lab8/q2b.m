clc;
clear all;
A = gallery('kahan', 90, 1.2, 100); % generates Kahan matrix
sig = svd(A); % computes singular values.
format short e
sig(1)
sig(89)
sig(90)
fprintf('svd rank A = %d\n',rank(A));

[Q,R,E] = qr(A);

dif = norm(eye(90)-E);
dif

R(90,90)
min(diag(R))

