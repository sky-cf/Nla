clc;
clear all
A = randn(7,4);
r1 = rank(A);
r1
A(:,5:6) = A(:,2:3) + A(:,3:4);
r2 = rank(A);
r2